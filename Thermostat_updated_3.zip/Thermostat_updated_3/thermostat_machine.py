"""Thermostat state machine and runtime display loop."""

from __future__ import annotations

from datetime import datetime
from collections import deque
from math import floor
from threading import Thread
from time import sleep
import os
import sqlite3

from statemachine import StateMachine, State

from config import DEBUG, DB_PATH, DB_LOG_INTERVAL_SECONDS
from display_manager import screen
from hardware import thSensor, redLight, blueLight, ser


class TemperatureMachine(StateMachine):
    """A state machine designed to manage our thermostat."""

    # Define the three states for our machine.
    off = State(initial=True)
    heat = State()
    cool = State()

    # Transition event
    cycle = (off.to(heat) | heat.to(cool) | cool.to(off))

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        # Default temperature setPoint
        self.setPoint = 72

        # Keep a short history of recent temperatures 
        self._recent_temps = deque(maxlen=5)

        # SQLite logging 
        self._db_conn = None
        self._db_path = self._resolve_db_path(DB_PATH)
        self._db_last_log_sec = 0  
        self._db_init()

    def _resolve_db_path(self, db_path: str) -> str:
        """
        Keep DB path behavior simple:
        - If you pass an absolute path, use it.
        - Otherwise, drop the DB next to this file.
        """
        if os.path.isabs(db_path):
            return db_path

        here = os.path.dirname(os.path.abspath(__file__))
        return os.path.join(here, db_path)

    def _db_init(self) -> None:
        """Create database + table if needed. If this fails, we keep running without DB logging."""
        try:
            # default is check_same_thread=True (fine because we only write from the display thread)
            self._db_conn = sqlite3.connect(self._db_path, timeout=10)

            cur = self._db_conn.cursor()
            cur.execute(
                """
                CREATE TABLE IF NOT EXISTS temperature_log (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    ts TEXT NOT NULL,
                    state TEXT NOT NULL,
                    temp_f INTEGER NOT NULL,
                    temp_f_raw INTEGER NOT NULL,
                    set_point INTEGER NOT NULL
                );
                """
            )
            cur.execute("CREATE INDEX IF NOT EXISTS idx_temperature_log_ts ON temperature_log(ts);")
            self._db_conn.commit()

            if DEBUG:
                print(f"DB ready: {self._db_path}")

        except Exception as exc:
            if DEBUG:
                print(f"DB init failed: {exc}")
            self._db_conn = None

    def _db_log(self, ts: datetime, state: str, temp_f: int, temp_f_raw: int, set_point: int) -> None:
        """Insert one row into the DB. If it fails, we keep running."""
        if self._db_conn is None:
            return

        try:
            cur = self._db_conn.cursor()
            cur.execute(
                "INSERT INTO temperature_log (ts, state, temp_f, temp_f_raw, set_point) VALUES (?, ?, ?, ?, ?);",
                (ts.isoformat(timespec="seconds"), state, int(temp_f), int(temp_f_raw), int(set_point)),
            )
            self._db_conn.commit()

        except Exception as exc:
            if DEBUG:
                print(f"DB log failed: {exc}")

    def on_enter_heat(self):
        self.updateLights()
        if DEBUG:
            print("* Changing state to heat")

    def on_exit_heat(self):
        redLight.off()

    def on_enter_cool(self):
        self.updateLights()
        if DEBUG:
            print("* Changing state to cool")

    def on_exit_cool(self):
        blueLight.off()

    def on_enter_off(self):
        redLight.off()
        blueLight.off()
        if DEBUG:
            print("* Changing state to off")

    def processTempStateButton(self):
        if DEBUG:
            print("Cycling Temperature State")
        self.cycle()

    def processTempIncButton(self):
        if DEBUG:
            print("Increasing Set Point")
        self.setPoint += 1
        self.updateLights()

    def processTempDecButton(self):
        if DEBUG:
            print("Decreasing Set Point")
        self.setPoint -= 1
        self.updateLights()

    def updateLights(self, temp: int | None = None):
        """Update lights based on mode and temperature."""
        if temp is None:
            temp = floor(self.getFahrenheit())

        redLight.off()
        blueLight.off()

        if DEBUG:
            print(f"State: {self.current_state.id}")
            print(f"SetPoint: {self.setPoint}")
            print(f"Temp: {temp}")

        if self.current_state.id == "off":
            return

        if self.current_state.id == "heat":
            if temp < self.setPoint:
                redLight.pulse()
            else:
                redLight.on()

        if self.current_state.id == "cool":
            if temp > self.setPoint:
                blueLight.pulse()
            else:
                blueLight.on()

    def run(self):
        display_thread = Thread(target=self.manageMyDisplay, daemon=True)
        display_thread.start()

    def getFahrenheit(self):
        t = thSensor.temperature
        return ((9 / 5) * t) + 32

    def setupSerialOutput(self, temp_f: int | None = None):
        """Return CSV payload for serial logging: state,tempF,setPoint"""
        if temp_f is None:
            temp_f = floor(self.getFahrenheit())

        return f"{self.current_state.id},{temp_f},{self.setPoint}"

    endDisplay = False

    def manageMyDisplay(self):
        """
        Main display loop.

        Improvement:
        Keep the last few temperature readings and
        display an average to reduce sensor noise.
        """
        altCounter = 0
        serialCounter = 0  # used like "seconds elapsed" since we sleep(1) each loop

        while not self.endDisplay:
            # Read raw temperature once per loop
            temp_f_raw = floor(self.getFahrenheit())

            # Store recent temps and compute average
            self._recent_temps.append(temp_f_raw)
            temp_f = floor(sum(self._recent_temps) / len(self._recent_temps))

            current_time = datetime.now()

            lcd_line_1 = current_time.strftime("%m/%d %H:%M:%S")

            # Alternate display every 5 seconds
            if altCounter < 5:
                lcd_line_2 = f"Temp: {temp_f}F"
            else:
                lcd_line_2 = f"{self.current_state.id} {self.setPoint}F"

            # Update lights every loop
            self.updateLights(temp=temp_f)

            # Update screen
            screen.updateScreen(lcd_line_1 + "\n" + lcd_line_2)

            # Send serial output every 30 seconds
            if serialCounter % 30 == 0:
                ser.write((self.setupSerialOutput(temp_f=temp_f) + "\n").encode())

            # Log to SQLite on an interval (in seconds)
            if (
                DB_LOG_INTERVAL_SECONDS > 0
                and self._db_conn is not None
                and (serialCounter - self._db_last_log_sec) >= DB_LOG_INTERVAL_SECONDS
            ):
                self._db_log(current_time, self.current_state.id, temp_f, temp_f_raw, self.setPoint)
                self._db_last_log_sec = serialCounter

            altCounter = (altCounter + 1) % 10
            serialCounter += 1

            sleep(1)

        # Shutdown cleanup
        if self._db_conn is not None:
            try:
                self._db_conn.close()
            except Exception:
                pass

        screen.cleanupDisplay()
