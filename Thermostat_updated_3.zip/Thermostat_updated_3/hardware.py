"""Hardware initialization for the thermostat project.

This module centralizes Raspberry Pi hardware setup (I2C sensor, UART, LEDs).
Keeping these objects here allows the rest of the application to import and use
them without changing overall runtime behavior.
"""

from __future__ import annotations

import board
import adafruit_ahtx0
import serial
from gpiozero import PWMLED

# Create an I2C instance so that we can communicate with devices on the I2C bus.
i2c = board.I2C()

# Initialize our Temperature and Humidity sensor
thSensor = adafruit_ahtx0.AHTx0(i2c)

# Initialize our serial connection (UART)
ser = serial.Serial(
    port="/dev/ttyS0",          # /dev/ttyAMA0 prior to Raspberry Pi 3
    baudrate=115200,            # bits/second
    parity=serial.PARITY_NONE,  # Disable parity
    stopbits=serial.STOPBITS_ONE,
    bytesize=serial.EIGHTBITS,
    timeout=1,                  # 1-second timeout
)

# Our two LEDs, utilizing GPIO 18, and GPIO 23
redLight = PWMLED(18)
blueLight = PWMLED(23)
