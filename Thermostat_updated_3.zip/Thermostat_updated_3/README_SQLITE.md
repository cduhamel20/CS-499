# SQLite Temperature Logging

This project logs temperature readings to a local SQLite database file.

## Where the DB lives
By default, the database file is created next to `thermostat_machine.py` (same folder as the thermostat code) as:

- `thermostat.db`

You can change the filename/path in `config.py` (`DB_PATH`).  
If `DB_PATH` is an absolute path, the DB will be created exactly there.

## Logging interval
Logging frequency is controlled by `DB_LOG_INTERVAL_SECONDS` in `config.py` (in seconds).  
Example: `30` = log every 30 seconds.

## Table
Rows are stored in:

- `temperature_log`

Columns:
- `id` (auto-increment primary key)
- `ts` (ISO timestamp, local time)
- `state` (`off`, `heat`, or `cool`)
- `temp_f` (averaged)
- `temp_f_raw` (raw reading)
- `set_point`

## Quick query
On the Pi:

```bash
sqlite3 thermostat.db "select ts,state,temp_f,set_point from temperature_log order by id desc limit 10;"
