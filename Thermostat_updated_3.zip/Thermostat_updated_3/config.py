"""Shared config for the thermostat."""

# DEBUG 
DEBUG = True

# Database logging (SQLite)
# The DB file will be created automatically if it does not exist.
DB_PATH = "thermostat.db"

# Log to the database every N seconds.
DB_LOG_INTERVAL_SECONDS = 30
