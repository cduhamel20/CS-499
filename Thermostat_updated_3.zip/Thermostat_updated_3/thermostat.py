"""Thermostat entry point.

This file wires together buttons and the TemperatureMachine.
Behavior is intended to match the original single-file implementation.
"""

from time import sleep
from gpiozero import Button

from thermostat_machine import TemperatureMachine


def main():
    # Setup our State Machine
    tsm = TemperatureMachine()
    tsm.run()

    # Configure buttons
    greenButton = Button(24)
    greenButton.when_pressed = tsm.processTempStateButton

    redButton = Button(25)
    redButton.when_pressed = tsm.processTempIncButton

    blueButton = Button(12)
    blueButton.when_pressed = tsm.processTempDecButton

    repeat = True
    while repeat:
        try:
            sleep(30)
        except KeyboardInterrupt:
            print("Cleaning up. Exiting...")
            repeat = False
            tsm.endDisplay = True
            sleep(1)


if __name__ == "__main__":
    main()
