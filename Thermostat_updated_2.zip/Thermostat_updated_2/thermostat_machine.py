"""Thermostat state machine and runtime display loop."""

from __future__ import annotations

from datetime import datetime
from collections import deque
from math import floor
from threading import Thread
from time import sleep

from statemachine import StateMachine, State

from config import DEBUG
from display_manager import screen
from hardware import thSensor, redLight, blueLight, ser


class TemperatureMachine(StateMachine):
    """A state machine designed to manage our thermostat."""

    # Define the three states for our machine.
    off = State(initial=True)
    heat = State()
    cool = State()

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        # Default temperature setPoint
        self.setPoint = 72

        # Keep a short history of recent temperatures
        self._recent_temps = deque(maxlen=5)

    # Transition event
    cycle = (off.to(heat) | heat.to(cool) | cool.to(off))

    def on_enter_heat(self):
        self.updateLights()
        if DEBUG:
            print("* Changing state to heat")

    def on_exit_heat(self):
        redLight.off()

    def on_enter_cool(self):
        self.updateLights()
        if DEBUG:
            print("* Changing state to cool")

    def on_exit_cool(self):
        blueLight.off()

    def on_enter_off(self):
        redLight.off()
        blueLight.off()
        if DEBUG:
            print("* Changing state to off")

    def processTempStateButton(self):
        if DEBUG:
            print("Cycling Temperature State")
        self.cycle()

    def processTempIncButton(self):
        if DEBUG:
            print("Increasing Set Point")
        self.setPoint += 1
        self.updateLights()

    def processTempDecButton(self):
        if DEBUG:
            print("Decreasing Set Point")
        self.setPoint -= 1
        self.updateLights()

    def updateLights(self, temp: int | None = None):
        """Update indicator lights based on mode and temperature."""

        if temp is None:
            temp = floor(self.getFahrenheit())

        redLight.off()
        blueLight.off()

        if DEBUG:
            print(f"State: {self.current_state.id}")
            print(f"SetPoint: {self.setPoint}")
            print(f"Temp: {temp}")

        if self.current_state.id == "off":
            return

        if self.current_state.id == "heat":
            if temp < self.setPoint:
                redLight.pulse()
            else:
                redLight.on()

        if self.current_state.id == "cool":
            if temp > self.setPoint:
                blueLight.pulse()
            else:
                blueLight.on()

    def run(self):
        display_thread = Thread(target=self.manageMyDisplay, daemon=True)
        display_thread.start()

    def getFahrenheit(self):
        t = thSensor.temperature
        return ((9 / 5) * t) + 32

    def setupSerialOutput(self, temp_f: int | None = None):
        """Return CSV payload for serial logging: state,tempF,setPoint"""
        if temp_f is None:
            temp_f = floor(self.getFahrenheit())

        return f"{self.current_state.id},{temp_f},{self.setPoint}"

    endDisplay = False

    def manageMyDisplay(self):
        """
        Main display + telemetry loop.

        Algorithm improvement:
        Keep the last few temperature readings and
        display an average to reduce sensor noise.
        """

        altCounter = 0
        serialCounter = 0

        while not self.endDisplay:

            # Read raw temperature once per loop
            temp_f_raw = floor(self.getFahrenheit())

            # Store recent temps and compute average
            self._recent_temps.append(temp_f_raw)
            temp_f = floor(sum(self._recent_temps) / len(self._recent_temps))

            current_time = datetime.now()

            lcd_line_1 = current_time.strftime("%m/%d %H:%M:%S")

            # Alternate display every 5 seconds
            if altCounter < 5:
                lcd_line_2 = f"Temp: {temp_f}F"
            else:
                lcd_line_2 = f"{self.current_state.id} {self.setPoint}F"

            # Update lights every loop using averaged temp
            self.updateLights(temp=temp_f)

            # Update screen (two-line format)
            screen.updateScreen(lcd_line_1 + "\n" + lcd_line_2)

            # Send serial output every 30 seconds
            if serialCounter % 30 == 0:
                ser.write((self.setupSerialOutput(temp_f=temp_f) + "\n").encode())

            altCounter = (altCounter + 1) % 10
            serialCounter += 1

            sleep(1)

        screen.cleanupDisplay()
