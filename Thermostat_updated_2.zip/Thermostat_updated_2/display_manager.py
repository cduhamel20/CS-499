"""LCD display management for the thermostat."""

import board
import digitalio
import adafruit_character_lcd.character_lcd as characterlcd


class ManagedDisplay:
    """Manages the 16x2 LCD display."""

    def __init__(self):
        # Setup the six GPIO lines to communicate with the display.
        self.lcd_rs = digitalio.DigitalInOut(board.D17)
        self.lcd_en = digitalio.DigitalInOut(board.D27)
        self.lcd_d4 = digitalio.DigitalInOut(board.D5)
        self.lcd_d5 = digitalio.DigitalInOut(board.D6)
        self.lcd_d6 = digitalio.DigitalInOut(board.D13)
        self.lcd_d7 = digitalio.DigitalInOut(board.D26)

        # Modify this if you have a different sized character LCD
        self.lcd_columns = 16
        self.lcd_rows = 2

        # Initialise the lcd class
        self.lcd = characterlcd.Character_LCD_Mono(
            self.lcd_rs,
            self.lcd_en,
            self.lcd_d4,
            self.lcd_d5,
            self.lcd_d6,
            self.lcd_d7,
            self.lcd_columns,
            self.lcd_rows,
        )

        # wipe LCD screen before we start
        self.lcd.clear()

        self.last_msg = None

    def cleanupDisplay(self):
        # Clear the LCD first - otherwise we won't be able to update it.
        self.lcd.clear()
        self.lcd_rs.deinit()
        self.lcd_en.deinit()
        self.lcd_d4.deinit()
        self.lcd_d5.deinit()
        self.lcd_d6.deinit()
        self.lcd_d7.deinit()

    def clear(self):
        self.lcd.clear()
        self.last_msg = None

    def updateScreen(self, message: str):
        if self.last_msg != message:
            self.lcd.clear()
            self.lcd.message = message
            self.last_msg = message


# Initialize our display 
screen = ManagedDisplay()
