"""Shared config for the thermostat."""

# DEBUG 
DEBUG = True
