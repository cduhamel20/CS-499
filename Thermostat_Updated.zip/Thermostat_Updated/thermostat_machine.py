"""Thermostat state machine and runtime display loop."""

from __future__ import annotations

from datetime import datetime
from math import floor
from threading import Thread
from time import sleep

from statemachine import StateMachine, State

from config import DEBUG
from display_manager import screen
from hardware import thSensor, redLight, blueLight, ser


class TemperatureMachine(StateMachine):
    """A state machine designed to manage our thermostat."""

    # Define the three states for our machine.
    off = State(initial=True)
    heat = State()
    cool = State()

    # Default temperature setPoint is 72 degrees Fahrenheit
    setPoint = 72

    # Transition event
    cycle = (off.to(heat) | heat.to(cool) | cool.to(off))

    def on_enter_heat(self):
        self.updateLights()
        if DEBUG:
            print("* Changing state to heat")

    def on_exit_heat(self):
        redLight.off()

    def on_enter_cool(self):
        self.updateLights()
        if DEBUG:
            print("* Changing state to cool")

    def on_exit_cool(self):
        blueLight.off()

    def on_enter_off(self):
        redLight.off()
        blueLight.off()
        if DEBUG:
            print("* Changing state to off")

    def processTempStateButton(self):
        if DEBUG:
            print("Cycling Temperature State")
        self.cycle()

    def processTempIncButton(self):
        if DEBUG:
            print("Increasing Set Point")
        self.setPoint = self.setPoint + 1
        self.updateLights()

    def processTempDecButton(self):
        if DEBUG:
            print("Decreasing Set Point")
        self.setPoint = self.setPoint - 1
        self.updateLights()

    def updateLights(self):
        # Make sure we are comparing temperatures in the correct scale
        temp = floor(self.getFahrenheit())
        redLight.off()
        blueLight.off()

        if DEBUG:
            print(f"State: {self.current_state.id}")
            print(f"SetPoint: {self.setPoint}")
            print(f"Temp: {temp}")

        if self.current_state.id == "off":
            redLight.off()
            blueLight.off()

        if self.current_state.id == "heat":
            blueLight.off()
            if temp < self.setPoint:
                redLight.pulse()
            else:
                redLight.on()

        if self.current_state.id == "cool":
            redLight.off()
            if temp > self.setPoint:
                blueLight.pulse()
            else:
                blueLight.on()

    def run(self):
        myThread = Thread(target=self.manageMyDisplay)
        myThread.start()

    def getFahrenheit(self):
        t = thSensor.temperature
        return (((9 / 5) * t) + 32)

    def setupSerialOutput(self):
        output = f"{self.current_state.id},{floor(self.getFahrenheit())},{self.setPoint}"
        return output

    # Continue display output
    endDisplay = False

    def manageMyDisplay(self):
        counter = 1
        altCounter = 1
        while not self.endDisplay:
            if DEBUG:
                print("Processing Display Info...")

            current_time = datetime.now()

            # Line 1: date/time
            lcd_line_1 = current_time.strftime("%m/%d %H:%M:%S") + "\n"

            # Line 2: alternate temp vs state/setpoint
            if altCounter < 6:
                lcd_line_2 = "Temp: " + str(floor(self.getFahrenheit())) + "F"
                altCounter = altCounter + 1
            else:
                lcd_line_2 = str(self.current_state.id) + " " + str(self.setPoint) + "F"
                altCounter = altCounter + 1
                if altCounter >= 11:
                    # Update lights every ~10 seconds to keep operations smooth
                    self.updateLights()
                    altCounter = 1

            screen.updateScreen(lcd_line_1 + lcd_line_2)

            if DEBUG:
                print(f"Counter: {counter}")

            # Update server every 30 seconds
            if (counter % 30) == 0:
                ser.write((self.setupSerialOutput() + "\n").encode())
                counter = 1
            else:
                counter = counter + 1

            sleep(1)

        screen.cleanupDisplay()
