"""Shared config for the thermostat."""

# DEBUG flag - whether or not to print CS 499 Milestone Two Guidelines and Rubric status messages on the console of the program
DEBUG = True
